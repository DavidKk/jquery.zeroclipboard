jquery.zeroclipboard
====================

Modify by zeroclipboard v1.1.7
